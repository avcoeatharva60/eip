# Electricity Info System

C++ backend + SQLite database + one web frontend that also runs as an Android app.

```
backend/   main.cpp (REST API, auth, SQLite schema), CMakeLists.txt, third_party/
web/       index.html (User/Admin/Host UI), manifest.json, sw.js, icon.svg
```

## Roles
| Role  | Login | Can do |
|-------|-------|--------|
| User  | none  | pick location, see status / reason / live timers, load-shedding schedule, send complaint (needs email) |
| Admin | 12-char ID + password | add custom locations (code like `PUN-A01`), set cut-off ON/OFF/SCHEDULED, reason, expected restore time, mark resolved, manage schedules, read complaints |
| Host  | 12-char ID + password | everything Admin can + create/disable/delete/reset **admin and host** accounts |

Rules enforced by the server: IDs are exactly 12 letters/digits. Passwords need 8+ chars with an uppercase letter, a lowercase letter, a number and a symbol. Passwords are stored as salted PBKDF2-SHA256 hashes. Logins lock for 5 minutes after 5 failures. The last host cannot be deleted.

## 1. Build the backend (Linux/macOS/WSL)
```bash
sudo apt install build-essential cmake libsqlite3-dev libssl-dev
cd backend/third_party
curl -LO https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h
curl -LO https://github.com/nlohmann/json/releases/latest/download/json.hpp
cd .. && mkdir build && cd build && cmake .. && make
```

## 2. Run (first host account is seeded from environment variables)
```bash
export SEED_HOST_ID=897806982179
export SEED_HOST_PASS='Atharva@11'
WEB_DIR=../../web ./server          # http://localhost:8080
```
The seed variables are only used when no host exists yet. Log in as Host, then **change this password and create your own accounts** (the credentials were shared in plain text, so treat them as compromised). Put the server behind HTTPS (nginx/Caddy) before real use.

## 3. Android app
**Option A – install as app (PWA):** open the site in Chrome on Android over HTTPS → menu → *Install app*.

**Option B – real APK with Capacitor:**
```bash
npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init PowerInfo com.example.powerinfo --web-dir=web
# in web/index.html set  const API_BASE='https://your-server.com'
npx cap add android && npx cap sync && npx cap open android   # build APK in Android Studio
```

## Notes
- Complaints are saved in the database and visible to Admin/Host with the user's email (tap to reply). To also auto-email them, add an SMTP/curl call after the `INSERT INTO complaints` in `main.cpp`.
- DB schema is in `main.cpp` (`SCHEMA`): accounts, locations, schedules, complaints, status_log.
