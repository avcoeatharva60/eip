// Electricity Info System - C++17 backend (cpp-httplib + nlohmann/json + SQLite3 + OpenSSL)
#include "third_party/httplib.h"
#include "third_party/json.hpp"
#include <sqlite3.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/crypto.h>
#include <iostream>
#include <map>
#include <mutex>
#include <ctime>
#include <functional>

using json = nlohmann::json;
static sqlite3* db;
static std::mutex dbm, sesm;

struct ApiError { int code; std::string msg; };
struct Session { std::string id, role; long long exp = 0; };
static std::map<std::string, Session> sessions;
static std::map<std::string, std::pair<int, long long>> fails; // id -> (count, first fail time)

static long long now() { return (long long)std::time(nullptr); }

// ---------- DB helpers ----------
static json q(const std::string& sql, const std::vector<std::string>& p = {}) {
  std::lock_guard<std::mutex> l(dbm);
  sqlite3_stmt* s;
  if (sqlite3_prepare_v2(db, sql.c_str(), -1, &s, nullptr) != SQLITE_OK) throw std::runtime_error(sqlite3_errmsg(db));
  for (size_t i = 0; i < p.size(); i++) sqlite3_bind_text(s, (int)i + 1, p[i].c_str(), -1, SQLITE_TRANSIENT);
  json rows = json::array();
  int rc;
  while ((rc = sqlite3_step(s)) == SQLITE_ROW) {
    json r;
    for (int c = 0; c < sqlite3_column_count(s); c++) {
      const char* n = sqlite3_column_name(s, c);
      int t = sqlite3_column_type(s, c);
      if (t == SQLITE_INTEGER) r[n] = (long long)sqlite3_column_int64(s, c);
      else if (t == SQLITE_NULL) r[n] = nullptr;
      else r[n] = std::string((const char*)sqlite3_column_text(s, c));
    }
    rows.push_back(r);
  }
  std::string err = sqlite3_errmsg(db);
  sqlite3_finalize(s);
  if (rc != SQLITE_DONE) throw std::runtime_error(err);
  return rows;
}
static long long changes() { std::lock_guard<std::mutex> l(dbm); return sqlite3_changes(db); }

static const char* SCHEMA = R"SQL(
CREATE TABLE IF NOT EXISTS accounts(
  id TEXT PRIMARY KEY, role TEXT NOT NULL CHECK(role IN('admin','host')),
  salt TEXT NOT NULL, hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
  created_by TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS locations(
  code TEXT PRIMARY KEY, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'ON',
  reason TEXT NOT NULL DEFAULT '', cut_start INTEGER NOT NULL DEFAULT 0,
  expected_restore INTEGER NOT NULL DEFAULT 0, updated_at INTEGER, updated_by TEXT);
CREATE TABLE IF NOT EXISTS schedules(
  id INTEGER PRIMARY KEY AUTOINCREMENT, location_code TEXT NOT NULL,
  day INTEGER NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS complaints(
  id INTEGER PRIMARY KEY AUTOINCREMENT, location_code TEXT NOT NULL, email TEXT NOT NULL,
  message TEXT NOT NULL, created_at INTEGER, resolved INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS status_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT, location_code TEXT, event TEXT, reason TEXT, ts INTEGER, by_id TEXT);
)SQL";

// ---------- Security helpers ----------
static std::string hex(const unsigned char* d, size_t n) {
  static const char* h = "0123456789abcdef"; std::string s;
  for (size_t i = 0; i < n; i++) { s += h[d[i] >> 4]; s += h[d[i] & 15]; }
  return s;
}
static std::string rnd(int n) { unsigned char b[64]; RAND_bytes(b, n); return hex(b, n); }
static std::string hashpw(const std::string& pw, const std::string& salt) {
  unsigned char out[32];
  PKCS5_PBKDF2_HMAC(pw.c_str(), (int)pw.size(), (const unsigned char*)salt.data(), (int)salt.size(), 100000, EVP_sha256(), 32, out);
  return hex(out, 32);
}
static bool validId(const std::string& s) {
  if (s.size() != 12) return false;
  for (char c : s) if (!isalnum((unsigned char)c)) return false;
  return true;
}
// password: >=8 chars, 1 uppercase, 1 lowercase, 1 digit, 1 symbol
static bool validPw(const std::string& p) {
  if (p.size() < 8 || p.size() > 64) return false;
  bool u = 0, l = 0, d = 0, s = 0;
  for (unsigned char c : p) { if (isupper(c)) u = 1; else if (islower(c)) l = 1; else if (isdigit(c)) d = 1; else if (!isspace(c)) s = 1; }
  return u && l && d && s;
}
static bool validCode(const std::string& s) {
  if (s.size() < 2 || s.size() > 16) return false;
  for (char c : s) if (!isalnum((unsigned char)c) && c != '-' && c != '_') return false;
  return true;
}
static bool validEmail(const std::string& e) {
  auto at = e.find('@');
  return e.size() <= 120 && at != std::string::npos && at > 0 && e.find('.', at) != std::string::npos && e.find(' ') == std::string::npos;
}
static std::string S(const json& b, const char* k) { return b.contains(k) && b[k].is_string() ? b[k].get<std::string>() : ""; }
static long long N(const json& b, const char* k) { return b.contains(k) && b[k].is_number() ? b[k].get<long long>() : 0; }

static Session auth(const httplib::Request& rq) {
  std::string h = rq.get_header_value("Authorization");
  if (h.rfind("Bearer ", 0) != 0) throw ApiError{401, "Login required"};
  std::lock_guard<std::mutex> l(sesm);
  auto it = sessions.find(h.substr(7));
  if (it == sessions.end() || it->second.exp < now()) throw ApiError{401, "Session expired"};
  return it->second;
}
static void revoke(const std::string& id) {
  std::lock_guard<std::mutex> l(sesm);
  for (auto it = sessions.begin(); it != sessions.end();) it = it->second.id == id ? sessions.erase(it) : std::next(it);
}

using Fn = std::function<json(const httplib::Request&, const json&, const Session*, int&)>;
// need: "" public, "admin" (admin or host), "host" (host only)
static void route(httplib::Server& s, const std::string& m, const std::string& path, const std::string& need, Fn f) {
  auto h = [=](const httplib::Request& rq, httplib::Response& rs) {
    int code = 200; json out;
    try {
      Session se; const Session* sp = nullptr;
      if (!need.empty()) {
        se = auth(rq); sp = &se;
        if (need == "host" && se.role != "host") throw ApiError{403, "Host access only"};
      }
      json b = json::object();
      if (!rq.body.empty()) { b = json::parse(rq.body, nullptr, false); if (b.is_discarded() || !b.is_object()) throw ApiError{400, "Bad JSON"}; }
      out = f(rq, b, sp, code);
    } catch (ApiError& e) { code = e.code; out = {{"error", e.msg}}; }
    catch (std::exception& e) { code = 500; out = {{"error", "Server error"}}; std::cerr << e.what() << "\n"; }
    rs.status = code; rs.set_content(out.dump(), "application/json");
  };
  if (m == "GET") s.Get(path, h); else if (m == "POST") s.Post(path, h);
  else if (m == "PUT") s.Put(path, h); else if (m == "DELETE") s.Delete(path, h);
}

static void logEvent(const std::string& loc, const std::string& ev, const std::string& reason, const std::string& by) {
  q("INSERT INTO status_log(location_code,event,reason,ts,by_id) VALUES(?,?,?,?,?)", {loc, ev, reason, std::to_string(now()), by});
}

int main() {
  const char* dbp = getenv("DB_PATH"); const char* web = getenv("WEB_DIR"); const char* port = getenv("PORT");
  if (sqlite3_open(dbp ? dbp : "electricity.db", &db) != SQLITE_OK) { std::cerr << "DB open failed\n"; return 1; }
  sqlite3_exec(db, SCHEMA, nullptr, nullptr, nullptr);

  // Host account from environment variables (not hard-coded in source).
  // If SEED_HOST_ID/SEED_HOST_PASS are set, that host is created, or its password is reset and
  // the account re-enabled, on every start. Unset them after first login.
  {
    const char* hid = getenv("SEED_HOST_ID"); const char* hpw = getenv("SEED_HOST_PASS");
    if (hid && hpw) {
      if (!validId(hid) || !validPw(hpw)) { std::cerr << "SEED_HOST_ID must be 12 letters/digits; SEED_HOST_PASS needs 8+ chars with upper, lower, digit, symbol.\n"; return 1; }
      std::string salt = rnd(16);
      if (q("SELECT id FROM accounts WHERE id=?", {hid}).empty())
        q("INSERT INTO accounts(id,role,salt,hash,created_by,created_at) VALUES(?,?,?,?,?,?)", {hid, "host", salt, hashpw(hpw, salt), "system", std::to_string(now())});
      else
        q("UPDATE accounts SET role='host',salt=?,hash=?,active=1 WHERE id=?", {salt, hashpw(hpw, salt), hid});
      std::cout << "Host account " << hid << " is ready (password set from SEED_HOST_PASS).\n";
    } else if (q("SELECT id FROM accounts WHERE role='host'").empty()) {
      std::cerr << "No host exists. Set SEED_HOST_ID and SEED_HOST_PASS and restart.\n"; return 1;
    }
  }

  httplib::Server svr;
  svr.set_default_headers({{"Access-Control-Allow-Origin", "*"}, {"Access-Control-Allow-Headers", "Content-Type, Authorization"},
                           {"Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS"}, {"X-Content-Type-Options", "nosniff"}});
  svr.Options(".*", [](const httplib::Request&, httplib::Response& r) { r.status = 204; });
  svr.set_payload_max_length(64 * 1024);

  // ---------- Login ----------
  route(svr, "POST", "/api/login", "", [](auto& rq, const json& b, const Session*, int&) -> json {
    std::string id = S(b, "id"), pw = S(b, "password"), role = S(b, "role");
    {
      std::lock_guard<std::mutex> l(sesm);
      auto& f = fails[id];
      if (now() - f.second > 300) f = {0, now()};
      if (f.first >= 5) throw ApiError{429, "Too many attempts. Try again in a few minutes."};
    }
    auto r = q("SELECT * FROM accounts WHERE id=? AND active=1", {id});
    bool ok = false;
    if (!r.empty() && r[0]["role"] == role) {
      std::string h = hashpw(pw, r[0]["salt"]), want = r[0]["hash"];
      ok = h.size() == want.size() && CRYPTO_memcmp(h.data(), want.data(), h.size()) == 0;
    }
    if (!ok) {
      std::cerr << "Login failed: " << (r.empty() ? "no active account with this ID" : (r[0]["role"] != role ? "wrong login page (account role is " + r[0]["role"].get<std::string>() + ")" : "wrong password")) << "\n";
      std::lock_guard<std::mutex> l(sesm); fails[id].first++; throw ApiError{401, "Invalid ID or password"}; }
    std::string tok = rnd(32);
    { std::lock_guard<std::mutex> l(sesm); fails.erase(id); sessions[tok] = {id, role, now() + 8 * 3600}; }
    return {{"token", tok}, {"id", id}, {"role", role}};
  });

  // ---------- Public (user, no login) ----------
  route(svr, "GET", "/api/locations", "", [](auto&, const json&, const Session*, int&) -> json {
    return {{"now", now()}, {"locations", q("SELECT code,name,status,reason,cut_start,expected_restore,updated_at FROM locations ORDER BY code")}};
  });
  route(svr, "GET", "/api/schedules/:code", "", [](auto& rq, const json&, const Session*, int&) -> json {
    return q("SELECT id,day,start_time,end_time,note FROM schedules WHERE location_code=? ORDER BY day,start_time", {rq.path_params.at("code")});
  });
  route(svr, "POST", "/api/complaints", "", [](auto&, const json& b, const Session*, int& c) -> json {
    std::string loc = S(b, "location_code"), em = S(b, "email"), msg = S(b, "message");
    if (!validEmail(em)) throw ApiError{400, "Enter a valid email"};
    if (msg.empty() || msg.size() > 1000) throw ApiError{400, "Message must be 1-1000 characters"};
    if (q("SELECT code FROM locations WHERE code=?", {loc}).empty()) throw ApiError{400, "Select a valid location"};
    q("INSERT INTO complaints(location_code,email,message,created_at) VALUES(?,?,?,?)", {loc, em, msg, std::to_string(now())});
    c = 201; return {{"ok", true}};
  });

  // ---------- Admin (admin or host) ----------
  route(svr, "POST", "/api/admin/locations", "admin", [](auto&, const json& b, const Session* se, int& c) -> json {
    std::string code = S(b, "code"), name = S(b, "name");
    if (!validCode(code)) throw ApiError{400, "Code: 2-16 letters/digits/-/_ (e.g. PUN-A01)"};
    if (name.empty() || name.size() > 80) throw ApiError{400, "Name required (max 80)"};
    if (!q("SELECT code FROM locations WHERE code=?", {code}).empty()) throw ApiError{409, "Code already exists"};
    q("INSERT INTO locations(code,name,updated_at,updated_by) VALUES(?,?,?,?)", {code, name, std::to_string(now()), se->id});
    c = 201; return {{"ok", true}};
  });
  route(svr, "PUT", "/api/admin/locations/:code", "admin", [](auto& rq, const json& b, const Session* se, int&) -> json {
    std::string code = rq.path_params.at("code"), st = S(b, "status"), reason = S(b, "reason");
    long long er = N(b, "expected_restore");
    auto r = q("SELECT status,cut_start FROM locations WHERE code=?", {code});
    if (r.empty()) throw ApiError{404, "Location not found"};
    if (st != "ON" && st != "OFF" && st != "SCHEDULED") throw ApiError{400, "Status must be ON, OFF or SCHEDULED"};
    if (reason.size() > 300) throw ApiError{400, "Reason too long"};
    long long cs = r[0]["cut_start"].get<long long>();
    if (st == "OFF" && r[0]["status"] != "OFF") cs = now();
    if (st == "ON") { cs = 0; er = 0; reason = ""; }
    if (st != "ON" && reason.empty()) throw ApiError{400, "Give a reason for the cut-off"};
    q("UPDATE locations SET status=?,reason=?,cut_start=?,expected_restore=?,updated_at=?,updated_by=? WHERE code=?",
      {st, reason, std::to_string(cs), std::to_string(er), std::to_string(now()), se->id, code});
    logEvent(code, st, reason, se->id);
    return {{"ok", true}};
  });
  route(svr, "POST", "/api/admin/locations/:code/resolve", "admin", [](auto& rq, const json&, const Session* se, int&) -> json {
    std::string code = rq.path_params.at("code");
    q("UPDATE locations SET status='ON',reason='',cut_start=0,expected_restore=0,updated_at=?,updated_by=? WHERE code=?",
      {std::to_string(now()), se->id, code});
    if (!changes()) throw ApiError{404, "Location not found"};
    logEvent(code, "RESOLVED", "", se->id);
    return {{"ok", true}};
  });
  route(svr, "DELETE", "/api/admin/locations/:code", "admin", [](auto& rq, const json&, const Session*, int&) -> json {
    std::string code = rq.path_params.at("code");
    q("DELETE FROM schedules WHERE location_code=?", {code});
    q("DELETE FROM locations WHERE code=?", {code});
    return {{"ok", true}};
  });
  route(svr, "POST", "/api/admin/schedules", "admin", [](auto&, const json& b, const Session*, int& c) -> json {
    std::string loc = S(b, "location_code"), st = S(b, "start_time"), en = S(b, "end_time"), note = S(b, "note");
    long long day = N(b, "day");
    auto okT = [](const std::string& t) { return t.size() == 5 && t[2] == ':' && isdigit(t[0]) && isdigit(t[1]) && isdigit(t[3]) && isdigit(t[4]); };
    if (q("SELECT code FROM locations WHERE code=?", {loc}).empty()) throw ApiError{400, "Invalid location"};
    if (day < 0 || day > 6 || !okT(st) || !okT(en) || note.size() > 120) throw ApiError{400, "Invalid schedule data"};
    q("INSERT INTO schedules(location_code,day,start_time,end_time,note) VALUES(?,?,?,?,?)", {loc, std::to_string(day), st, en, note});
    c = 201; return {{"ok", true}};
  });
  route(svr, "DELETE", "/api/admin/schedules/:id", "admin", [](auto& rq, const json&, const Session*, int&) -> json {
    q("DELETE FROM schedules WHERE id=?", {rq.path_params.at("id")}); return {{"ok", true}};
  });
  route(svr, "GET", "/api/admin/complaints", "admin", [](auto&, const json&, const Session*, int&) -> json {
    return q("SELECT * FROM complaints ORDER BY resolved, id DESC LIMIT 300");
  });
  route(svr, "PUT", "/api/admin/complaints/:id/resolve", "admin", [](auto& rq, const json&, const Session*, int&) -> json {
    q("UPDATE complaints SET resolved=1 WHERE id=?", {rq.path_params.at("id")}); return {{"ok", true}};
  });
  route(svr, "GET", "/api/admin/log", "admin", [](auto&, const json&, const Session*, int&) -> json {
    return q("SELECT * FROM status_log ORDER BY id DESC LIMIT 100");
  });

  // ---------- Host only ----------
  route(svr, "GET", "/api/host/accounts", "host", [](auto&, const json&, const Session*, int&) -> json {
    return q("SELECT id,role,active,created_by,created_at FROM accounts ORDER BY role,id");
  });
  route(svr, "POST", "/api/host/accounts", "host", [](auto&, const json& b, const Session* se, int& c) -> json {
    std::string id = S(b, "id"), pw = S(b, "password"), role = S(b, "role");
    if (!validId(id)) throw ApiError{400, "ID must be exactly 12 letters/digits"};
    if (role != "admin" && role != "host") throw ApiError{400, "Role must be admin or host"};
    if (!validPw(pw)) throw ApiError{400, "Password: 8+ chars with uppercase, lowercase, number and symbol"};
    if (!q("SELECT id FROM accounts WHERE id=?", {id}).empty()) throw ApiError{409, "ID already exists"};
    std::string salt = rnd(16);
    q("INSERT INTO accounts(id,role,salt,hash,created_by,created_at) VALUES(?,?,?,?,?,?)",
      {id, role, salt, hashpw(pw, salt), se->id, std::to_string(now())});
    c = 201; return {{"ok", true}};
  });
  route(svr, "PUT", "/api/host/accounts/:id", "host", [](auto& rq, const json& b, const Session* se, int&) -> json {
    std::string id = rq.path_params.at("id");
    auto r = q("SELECT role FROM accounts WHERE id=?", {id});
    if (r.empty()) throw ApiError{404, "Account not found"};
    if (b.contains("password")) {
      std::string pw = S(b, "password");
      if (!validPw(pw)) throw ApiError{400, "Password: 8+ chars with uppercase, lowercase, number and symbol"};
      std::string salt = rnd(16);
      q("UPDATE accounts SET salt=?,hash=? WHERE id=?", {salt, hashpw(pw, salt), id});
      revoke(id);
    }
    if (b.contains("active") && b["active"].is_boolean()) {
      bool a = b["active"];
      if (!a && id == se->id) throw ApiError{400, "You cannot disable yourself"};
      q("UPDATE accounts SET active=? WHERE id=?", {a ? "1" : "0", id});
      if (!a) revoke(id);
    }
    return {{"ok", true}};
  });
  route(svr, "DELETE", "/api/host/accounts/:id", "host", [](auto& rq, const json&, const Session* se, int&) -> json {
    std::string id = rq.path_params.at("id");
    if (id == se->id) throw ApiError{400, "You cannot delete yourself"};
    auto r = q("SELECT role FROM accounts WHERE id=?", {id});
    if (r.empty()) throw ApiError{404, "Account not found"};
    if (r[0]["role"] == "host" && q("SELECT id FROM accounts WHERE role='host' AND active=1").size() <= 1)
      throw ApiError{400, "Cannot delete the last host"};
    q("DELETE FROM accounts WHERE id=?", {id}); revoke(id);
    return {{"ok", true}};
  });

  svr.set_mount_point("/", web ? web : "../web");
  int p = port ? atoi(port) : 8080;
  std::cout << "Server on http://0.0.0.0:" << p << "\n";
  svr.listen("0.0.0.0", p);
  return 0;
}
