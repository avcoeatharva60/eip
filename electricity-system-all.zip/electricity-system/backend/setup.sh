#!/bin/sh
# Downloads the two header libraries, builds, and starts the server.
set -e
cd "$(dirname "$0")"
mkdir -p third_party build
[ -f third_party/httplib.h ] || curl -L -o third_party/httplib.h https://raw.githubusercontent.com/yhirose/cpp-httplib/master/httplib.h
[ -f third_party/json.hpp ]  || curl -L -o third_party/json.hpp  https://github.com/nlohmann/json/releases/latest/download/json.hpp
cd build && cmake .. && make
echo "Build done. Start with:"
echo "  export SEED_HOST_ID=897806982179"
echo "  export SEED_HOST_PASS='Atharva@11'"
echo "  WEB_DIR=../../web ./server"
